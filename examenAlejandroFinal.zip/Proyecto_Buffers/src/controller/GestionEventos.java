package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JTextField;

import model.*;
import view.*;

public class GestionEventos {

	private GestionDatos model;
	private LaunchView view;
	private ActionListener actionListener_comparar, actionListener_buscar, actionListener_guardar,
			actionListener_recuperar, actionListener_recuperarTodo,actionListener_recuperarPorAnyo,actionListener_recuperarPorPrefijo;

	public GestionEventos(GestionDatos model, LaunchView view) {
		this.model = model;
		this.view = view;
	}

	public void contol() {

		actionListener_comparar = new ActionListener() {

			public void actionPerformed(ActionEvent actionEvent) {

				if (call_compararContenido() == false) {

					view.getTextArea().setText("Distintos");

				} else {
					view.getTextArea().setText("Iguales");
				}
			}
		};
		view.getComparar().addActionListener(actionListener_comparar);

		actionListener_buscar = new ActionListener() {

			public void actionPerformed(ActionEvent actionEvent) {
				if (call_buscarPalabra() == 0) {
					view.getTextArea().setText("La palabra no está");

				} else {
					view.getTextArea().setText("En la inea " + call_buscarPalabra() + " aparece la palabra");
				}
			}
		};
		view.getBuscar().addActionListener(actionListener_buscar);

		actionListener_guardar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				call_crearLibro();

			}

		};
		view.getGuardar().addActionListener(actionListener_guardar);

		actionListener_recuperar = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				call_recuperarLibro();
			}

		};
		view.getLeer_Libros().addActionListener(actionListener_recuperar);

		actionListener_recuperarTodo = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				System.out.println("Estoy aqui22");
				call_recuperarTodo();
			}

		};
		view.getRecu_todo().addActionListener(actionListener_recuperarTodo);
		
		actionListener_recuperarPorAnyo = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				System.out.println("Estoy aqui22");
				call_recuperarTodoByAnyo();
			}

		};
		
		view.getBtnPorAnyo().addActionListener(actionListener_recuperarPorAnyo);
		
		
		actionListener_recuperarPorPrefijo = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			if(call_recuperarPorPrefijo() > 0) {
			view.getTextArea().setText("Esta palabra se repite: " +call_recuperarPorPrefijo());	
			}
			else {
				view.showError("Error no se ha encotrado ninguna palabra.");
				
			}
			}

		};
		
		view.getBtnPrefijopalabra().addActionListener(actionListener_recuperarPorPrefijo);
		
		
		
		
	}

	private boolean call_compararContenido() {

		// TODO: Llamar a la funci�n compararContenido de GestionDatos
		String fich1 = view.getFichero1().getText();
		String fich2 = view.getFichero2().getText();

		try {

			return model.compararContenido(fich1, fich2);

		} catch (IOException e) {

			// LLAMAR AL SHOWERROR DE LA VISTA

			view.showError("Error al comparar ficheros.");
			e.printStackTrace();
		}
		return true;
	}

	private int call_buscarPalabra() {

		String fich1 = view.getFichero1().getText();
		String palabra = view.getPalabra().getText();
		boolean primera = view.getPrimera().isSelected();

		try {
			return model.buscarPalabra(fich1, palabra, primera);

		} catch (IOException e) {

			// LLAMAR AL SHOWERROR DE LA VISTA

			view.showError("Error al comparar ficheros.");
			e.printStackTrace();
		}

		return 0;
	}

	private void call_crearLibro() {

		String ID = view.getText_ID().getText();
		String titulo = view.getText_titulo().getText();
		String autor = view.getText_autor().getText();
		String ano = view.getText_ano().getText();
		String editorial = view.getText_editor().getText();
		String pagina = view.getText_paginas().getText();

		Libro L1 = new Libro(ID, titulo, autor, ano, editorial, pagina);

		try {
			model.crear_libro(L1);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void call_recuperarLibro() {

		String nom = view.getText_file().getText();

		try {
			Libro l = model.recuperar_libro(nom);
			view.getTextArea()
					.setText("ID:" + l.getID() + "\n" + "Titulo:" + l.getTitulo() + "\n" + "Autor:" + l.getAutor()
							+ "\n" + "Año:" + l.getAno() + "\n" + "Editorial:" + l.getEditorial() + "\n" + "Paginas:"
							+ l.getPaginas());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private void call_recuperarTodo() {
		System.out.println("Estoy aqui");
		view.getTextArea().setText(null);

		try {
			ArrayList<Libro> libros = model.recuperarTodo();

			Iterator it = libros.iterator();
			while (it.hasNext()) {

				Libro L1 = (Libro) it.next();

				view.getTextArea()
						.setText(view.getTextArea().getText() + "ID:" + L1.getID() + "\n" + "Titulo:" + L1.getTitulo()
								+ "\n" + "Autor:" + L1.getAutor() + "\n" + "Año:" + L1.getAno() + "\n" + "Editorial:"
								+ L1.getEditorial() + "\n" + "Paginas:" + L1.getPaginas());
				view.getTextArea()
						.setText(view.getTextArea().getText() + "\n ---------------------------------------------");
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	//EXAMEN
	private int  call_recuperarPorPrefijo() {
		String fichero1 = view.getFichero1().getText();
		String prefijo = view.getPalabra().getText();
		System.out.println("Estoy prefijo");
		
		 try {
			return model.palabraPrefijo(fichero1, prefijo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			view.showError("Error al buscar el texto a�adido.");
			e.printStackTrace();
		}
		return 0;
	}
	private void call_recuperarTodoByAnyo() {
		System.out.println("Estoy anyo");
		view.getTextArea().setText(null);
		String anyo = view.getText_ano().getText();
		System.out.println(anyo);

		try {
			ArrayList<Libro> libros = model.recuperarPorAnyo();

			Iterator it = libros.iterator();
			while (it.hasNext()) {

				Libro L1 = (Libro) it.next();
				if(L1.getAno().compareTo(anyo) == 0) {
					view.getTextArea()
							.setText(view.getTextArea().getText() + "ID:" + L1.getID() + "\n" + "Titulo:"
									+ L1.getTitulo() + "\n" + "Autor:" + L1.getAutor() + "\n" + "Año:" + L1.getAno()
									+ "\n" + "Editorial:" + L1.getEditorial() + "\n" + "Paginas:" + L1.getPaginas());
					view.getTextArea()
							.setText(view.getTextArea().getText() + "\n ---------------------------------------------");

				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
